            List of relations
 Schema |    Name     | Type  |   Owner   
--------+-------------+-------+-----------
 public | avoir_note  | table | enzolutic
 public | enseignants | table | enzolutic
 public | epreuves    | table | enzolutic
 public | etudiants   | table | enzolutic
 public | faire_cours | table | enzolutic
 public | matieres    | table | enzolutic
 public | modules     | table | enzolutic
(7 rows)

 numetu |   nometu    
--------+-------------
      1 | roblin
      2 | athur
      3 | minol
      4 | bagnole
      5 | bury
      6 | vendraux
      7 | vendermaele
      8 | besson
      9 | jean-paul
(9 rows)

